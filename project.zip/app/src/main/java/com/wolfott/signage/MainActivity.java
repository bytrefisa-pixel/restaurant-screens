package com.wolfott.signage;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Full-screen slideshow: dish photos with name/price, plus videos, looping forever.
 * Hidden menu: press BACK 5 times quickly (or the MENU key).
 */
public class MainActivity extends Activity {

    private static final long SYNC_INTERVAL_MS = 10 * 60 * 1000L;
    private static final int FADE_MS = 900;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private ContentSync sync;

    private ImageView imageA;
    private ImageView imageB;
    private boolean frontIsA = false;
    private VideoView video;
    private LinearLayout captionBox;
    private TextView titleText;
    private TextView priceText;
    private TextView statusText;

    private Playlist playlist;
    private Playlist pending;
    private int index = -1;
    private int missCount = 0;
    private boolean running = false;

    private int lastVideoPos = -1;
    private int stalledChecks = 0;

    private int backCount = 0;
    private long firstBackAt = 0;
    private int screenW = 1920;
    private int screenH = 1080;

    private final Runnable advance = this::next;

    private final Runnable syncLoop = new Runnable() {
        @Override
        public void run() {
            syncNow(false);
            handler.postDelayed(this, SYNC_INTERVAL_MS);
        }
    };

    /** Skips a video that freezes instead of leaving a frozen screen. */
    private final Runnable videoWatch = new Runnable() {
        @Override
        public void run() {
            if (video.getVisibility() != View.VISIBLE) return;
            int pos = video.getCurrentPosition();
            if (pos == lastVideoPos) {
                stalledChecks++;
                if (stalledChecks >= 2) {
                    next();
                    return;
                }
            } else {
                stalledChecks = 0;
            }
            lastVideoPos = pos;
            handler.postDelayed(this, 10000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        screenW = Math.max(dm.widthPixels, dm.heightPixels);
        screenH = Math.min(dm.widthPixels, dm.heightPixels);

        sync = new ContentSync(this);
        buildUi();
        playlist = sync.loadLocal();
        handler.post(syncLoop);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        running = true;
        next();
    }

    @Override
    protected void onPause() {
        super.onPause();
        running = false;
        handler.removeCallbacks(advance);
        handler.removeCallbacks(videoWatch);
        stopVideo();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    // ---------------- UI ----------------

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        imageA = makeImage();
        imageB = makeImage();
        root.addView(imageA, matchParent());
        root.addView(imageB, matchParent());

        video = new VideoView(this);
        video.setVisibility(View.GONE);
        root.addView(video, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));

        captionBox = new LinearLayout(this);
        captionBox.setOrientation(LinearLayout.VERTICAL);
        captionBox.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        captionBox.setPadding(dp(48), dp(80), dp(56), dp(36));
        captionBox.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xE6000000, 0x99000000, 0x00000000}));
        captionBox.setVisibility(View.GONE);

        titleText = new TextView(this);
        titleText.setTextColor(Color.WHITE);
        titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44);
        titleText.setTypeface(Typeface.DEFAULT_BOLD);
        titleText.setGravity(Gravity.RIGHT);
        titleText.setShadowLayer(8, 0, 2, Color.BLACK);
        captionBox.addView(titleText);

        priceText = new TextView(this);
        priceText.setTextColor(0xFFFFC857);
        priceText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
        priceText.setTypeface(Typeface.DEFAULT_BOLD);
        priceText.setGravity(Gravity.RIGHT);
        priceText.setShadowLayer(8, 0, 2, Color.BLACK);
        captionBox.addView(priceText);

        root.addView(captionBox, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        statusText = new TextView(this);
        statusText.setTextColor(0xCCFFFFFF);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        statusText.setGravity(Gravity.CENTER);
        statusText.setVisibility(View.GONE);
        root.addView(statusText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        setContentView(root);
    }

    private ImageView makeImage() {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.CENTER_CROP);
        v.setAlpha(0f);
        return v;
    }

    private FrameLayout.LayoutParams matchParent() {
        return new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void showStatus(String text) {
        statusText.setText(text);
        statusText.setVisibility(View.VISIBLE);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    // ---------------- Playback ----------------

    private void next() {
        handler.removeCallbacks(advance);
        handler.removeCallbacks(videoWatch);
        if (!running) return;

        if (pending != null) {
            playlist = pending;
            pending = null;
            index = -1;
            missCount = 0;
        }

        if (playlist == null || playlist.items.isEmpty()) {
            stopVideo();
            captionBox.setVisibility(View.GONE);
            showStatus("جاري تحميل المحتوى…");
            handler.postDelayed(advance, 5000);
            return;
        }

        index = (index + 1) % playlist.items.size();
        Playlist.Item item = playlist.items.get(index);
        File f = sync.fileFor(item);
        if (!f.exists() || f.length() == 0) {
            missCount++;
            if (missCount >= playlist.items.size()) {
                missCount = 0;
                showStatus("جاري تحميل الصور والفيديو…");
                handler.postDelayed(advance, 5000);
            } else {
                handler.post(advance);
            }
            return;
        }
        missCount = 0;
        statusText.setVisibility(View.GONE);

        if (item.isVideo()) {
            playVideo(item, f);
        } else {
            showImage(item, f);
        }
    }

    private void showImage(Playlist.Item item, File f) {
        Bitmap bmp = decodeScaled(f);
        if (bmp == null) {
            handler.postDelayed(advance, 300);
            return;
        }
        stopVideo();

        final ImageView in = frontIsA ? imageB : imageA;
        final ImageView out = frontIsA ? imageA : imageB;
        frontIsA = !frontIsA;

        in.animate().cancel();
        out.animate().cancel();
        in.setScaleType(item.contain ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
        in.setImageBitmap(bmp);
        in.setAlpha(0f);
        in.animate().alpha(1f).setDuration(FADE_MS).start();
        out.animate().alpha(0f).setDuration(FADE_MS).withEndAction(() -> out.setImageDrawable(null)).start();

        showCaption(item);
        handler.postDelayed(advance, item.seconds * 1000L);
    }

    private void playVideo(final Playlist.Item item, File f) {
        showCaption(item);
        lastVideoPos = -1;
        stalledChecks = 0;
        video.setVisibility(View.VISIBLE);
        video.setOnPreparedListener(mp -> {
            if (item.mute) mp.setVolume(0f, 0f);
            mp.setLooping(false);
            video.start();
        });
        video.setOnCompletionListener(mp -> next());
        video.setOnErrorListener((mp, what, extra) -> {
            handler.postDelayed(advance, 500);
            return true;
        });
        video.setVideoPath(f.getAbsolutePath());
        handler.postDelayed(videoWatch, 15000);
    }

    private void stopVideo() {
        if (video != null && video.getVisibility() == View.VISIBLE) {
            try {
                video.stopPlayback();
            } catch (Exception ignored) {
            }
            video.setVisibility(View.GONE);
        }
    }

    private void showCaption(Playlist.Item item) {
        boolean hasTitle = !item.title.isEmpty();
        boolean hasPrice = !item.price.isEmpty();
        if (!hasTitle && !hasPrice) {
            captionBox.setVisibility(View.GONE);
            return;
        }
        titleText.setText(item.title);
        titleText.setVisibility(hasTitle ? View.VISIBLE : View.GONE);
        priceText.setText(item.price);
        priceText.setVisibility(hasPrice ? View.VISIBLE : View.GONE);
        captionBox.setVisibility(View.VISIBLE);
        captionBox.setAlpha(0f);
        captionBox.animate().alpha(1f).setDuration(FADE_MS).start();
    }

    /** Loads a photo at screen size only, to stay light on the TV's small memory. */
    private Bitmap decodeScaled(File f) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= screenW && bounds.outHeight / (sample * 2) >= screenH) {
                sample *= 2;
            }
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), opts);
        } catch (OutOfMemoryError e) {
            System.gc();
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------- Content sync ----------------

    private void syncNow(final boolean manual) {
        if (manual) toast("جاري تحديث المحتوى…");
        worker.execute(() -> {
            final ContentSync.Result r = sync.sync();
            handler.post(() -> {
                if (isFinishing()) return;
                if (r.playlist != null && r.changed) {
                    if (playlist == null || playlist.items.isEmpty()) {
                        playlist = r.playlist;
                        index = -1;
                        if (running) next();
                    } else {
                        pending = r.playlist;
                    }
                }
                if (manual) {
                    toast(r.error == null ? "تم التحديث ✓" : "تنبيه: " + r.error);
                }
            });
        });
    }

    // ---------------- Hidden menu ----------------

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showMenu();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            long now = SystemClock.uptimeMillis();
            if (now - firstBackAt > 4000) {
                firstBackAt = now;
                backCount = 0;
            }
            backCount++;
            if (backCount >= 5) {
                backCount = 0;
                showMenu();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        // Ignore: the player must not close by accident.
    }

    private boolean isHomeModeOn() {
        int state = getPackageManager().getComponentEnabledSetting(homeAlias());
        return state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED;
    }

    private ComponentName homeAlias() {
        return new ComponentName(this, getPackageName() + ".HomeAlias");
    }

    private void showMenu() {
        int count = playlist == null ? 0 : playlist.items.size();
        long last = sync.getLastSync();
        String lastText = last == 0 ? "لم يتم بعد"
                : new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(new Date(last));
        String title = "عرض المطعم — " + count + " عنصر — آخر تحديث: " + lastText;

        final boolean homeOn = isHomeModeOn();
        String[] options = {
                "تحديث المحتوى الآن",
                "إعدادات الشاشة",
                "فتح واجهة الشاشة الأصلية",
                homeOn ? "إيقاف الفتح التلقائي (وضع الواجهة الرئيسية)" : "تفعيل الفتح التلقائي (وضع الواجهة الرئيسية)",
                "إذن الظهور فوق التطبيقات",
                "تغيير رابط المحتوى",
                "إغلاق القائمة"
        };

        //noinspection deprecation
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(title)
                .setItems(options, (d, which) -> {
                    switch (which) {
                        case 0:
                            syncNow(true);
                            break;
                        case 1:
                            safeStart(new Intent(Settings.ACTION_SETTINGS));
                            break;
                        case 2:
                            openOriginalLauncher();
                            break;
                        case 3:
                            getPackageManager().setComponentEnabledSetting(homeAlias(),
                                    homeOn ? PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                                            : PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                                    PackageManager.DONT_KILL_APP);
                            toast(homeOn ? "تم إيقاف وضع الواجهة الرئيسية" : "تم تفعيل وضع الواجهة الرئيسية");
                            break;
                        case 4:
                            requestOverlay();
                            break;
                        case 5:
                            editUrl();
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void safeStart(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("هذا الخيار غير متاح في هذه الشاشة");
        }
    }

    private void openOriginalLauncher() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        List<ResolveInfo> list = getPackageManager().queryIntentActivities(home, 0);
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null || getPackageName().equals(ri.activityInfo.packageName)) continue;
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_HOME);
            i.setClassName(ri.activityInfo.packageName, ri.activityInfo.name);
            safeStart(i);
            return;
        }
        toast("ما لقيت واجهة ثانية في الشاشة");
    }

    private void requestOverlay() {
        if (Build.VERSION.SDK_INT < 23) {
            toast("الإذن مفعّل تلقائياً في هذا الإصدار");
            return;
        }
        if (Settings.canDrawOverlays(this)) {
            toast("الإذن مفعّل ✓");
            return;
        }
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("الإعداد غير متاح بالشاشة — فعّله بأمر ADB");
        }
    }

    private void editUrl() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(sync.getBaseUrl());
        input.setSelectAllOnFocus(true);
        //noinspection deprecation
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("رابط مجلد المحتوى")
                .setView(input)
                .setPositiveButton("حفظ", (d, w) -> {
                    sync.setBaseUrl(input.getText().toString());
                    syncNow(true);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }
}
