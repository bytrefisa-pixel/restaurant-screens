package com.wolfott.signage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** The list of slides read from content/playlist.json. */
class Playlist {

    static class Item {
        String type;
        String file;
        String title;
        String price;
        int seconds;
        boolean mute;
        boolean contain;

        boolean isVideo() {
            return "video".equals(type);
        }
    }

    final List<Item> items = new ArrayList<>();

    static Playlist parse(String json) throws JSONException {
        JSONObject root = new JSONObject(json);
        int defSeconds = root.optInt("imageSeconds", 8);
        boolean defMute = root.optBoolean("mute", false);
        String defFit = root.optString("fit", "cover");

        Playlist p = new Playlist();
        JSONArray arr = root.getJSONArray("items");
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null || o.optBoolean("hidden", false)) continue;
            String file = clean(o.optString("file", ""));
            if (file.isEmpty()) continue;

            Item it = new Item();
            it.file = file;
            String type = clean(o.optString("type", "")).toLowerCase(Locale.ROOT);
            it.type = type.isEmpty() ? guessType(file) : type;
            it.title = clean(o.optString("title", ""));
            it.price = clean(o.optString("price", ""));
            it.seconds = Math.max(3, o.optInt("seconds", defSeconds));
            it.mute = o.optBoolean("mute", defMute);
            it.contain = "contain".equalsIgnoreCase(o.optString("fit", defFit));
            p.items.add(it);
        }
        return p;
    }

    private static String clean(String s) {
        if (s == null || "null".equals(s)) return "";
        return s.trim();
    }

    private static String guessType(String file) {
        String f = file.toLowerCase(Locale.ROOT);
        String[] videoExt = {".mp4", ".m4v", ".mkv", ".webm", ".mov", ".3gp", ".ts"};
        for (String ext : videoExt) {
            if (f.endsWith(ext)) return "video";
        }
        return "image";
    }
}
