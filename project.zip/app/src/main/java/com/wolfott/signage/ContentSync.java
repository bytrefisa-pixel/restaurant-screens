package com.wolfott.signage;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * Downloads playlist.json and every photo/video it lists into the TV's own storage,
 * so the slideshow keeps running even when the internet is down.
 */
class ContentSync {

    static class Result {
        Playlist playlist;
        boolean changed;
        String error;
    }

    private static final String PLAYLIST = "playlist.json";

    private final Context ctx;
    private final File mediaDir;
    private final SharedPreferences prefs;

    ContentSync(Context context) {
        ctx = context.getApplicationContext();
        mediaDir = new File(ctx.getFilesDir(), "media");
        //noinspection ResultOfMethodCallIgnored
        mediaDir.mkdirs();
        prefs = ctx.getSharedPreferences("signage", Context.MODE_PRIVATE);
    }

    String getBaseUrl() {
        String u = prefs.getString("url", BuildConfig.CONTENT_URL);
        if (u == null) u = "";
        u = u.trim();
        if (!u.isEmpty() && !u.endsWith("/")) u += "/";
        return u;
    }

    void setBaseUrl(String url) {
        prefs.edit().putString("url", url == null ? "" : url.trim()).apply();
    }

    long getLastSync() {
        return prefs.getLong("lastSync", 0);
    }

    File fileFor(Playlist.Item item) {
        return new File(mediaDir, item.file.replaceAll("[^A-Za-z0-9._\\-]", "_"));
    }

    Playlist loadLocal() {
        File f = new File(ctx.getFilesDir(), PLAYLIST);
        if (!f.exists()) return null;
        try {
            return Playlist.parse(readFile(f));
        } catch (Exception e) {
            return null;
        }
    }

    synchronized Result sync() {
        Result r = new Result();
        String base = getBaseUrl();
        if (base.isEmpty()) {
            r.error = "رابط المحتوى غير محدد";
            return r;
        }
        try {
            String json = new String(fetch(base + PLAYLIST + "?nocache=" + System.currentTimeMillis()), "UTF-8");
            Playlist p = Playlist.parse(json);

            boolean downloaded = false;
            Set<String> keep = new HashSet<>();
            String firstError = null;
            for (Playlist.Item item : p.items) {
                File f = fileFor(item);
                keep.add(f.getName());
                String url = base + encodePath(item.file);
                try {
                    boolean need = !f.exists() || f.length() == 0;
                    if (!need) {
                        long remote = headLength(url);
                        need = remote > 0 && remote != f.length();
                    }
                    if (need) {
                        download(url, f);
                        downloaded = true;
                    }
                } catch (Exception e) {
                    if (firstError == null) firstError = item.file + ": " + describe(e);
                }
            }

            File local = new File(ctx.getFilesDir(), PLAYLIST);
            String old = local.exists() ? readFile(local) : "";
            boolean changed = downloaded || !old.equals(json);
            if (changed) writeFile(local, json);

            File[] files = mediaDir.listFiles();
            if (files != null) {
                for (File x : files) {
                    if (!keep.contains(x.getName())) {
                        //noinspection ResultOfMethodCallIgnored
                        x.delete();
                    }
                }
            }

            prefs.edit().putLong("lastSync", System.currentTimeMillis()).apply();
            r.playlist = p;
            r.changed = changed;
            r.error = firstError;
        } catch (Exception e) {
            r.error = describe(e);
        }
        return r;
    }

    // ---------- networking helpers ----------

    private static String describe(Exception e) {
        String m = e.getMessage();
        return m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
    }

    private static String encodePath(String path) {
        String[] parts = path.split("/");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append('/');
            sb.append(Uri.encode(parts[i]));
        }
        return sb.toString();
    }

    private static HttpURLConnection open(String url, String method) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        c.setUseCaches(false);
        c.setRequestProperty("User-Agent", "WolfSignage/1.0");
        c.setRequestProperty("Accept-Encoding", "identity");
        return c;
    }

    private static byte[] fetch(String url) throws IOException {
        HttpURLConnection c = open(url, "GET");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            copy(in, out);
            in.close();
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static long headLength(String url) {
        HttpURLConnection c = null;
        try {
            c = open(url, "HEAD");
            if (c.getResponseCode() != 200) return -1;
            return c.getContentLength();
        } catch (Exception e) {
            return -1;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void download(String url, File dest) throws IOException {
        HttpURLConnection c = open(url, "GET");
        File tmp = new File(dest.getParentFile(), dest.getName() + ".part");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code);
            InputStream in = c.getInputStream();
            OutputStream out = new FileOutputStream(tmp);
            try {
                copy(in, out);
            } finally {
                out.close();
                in.close();
            }
            if (dest.exists() && !dest.delete()) throw new IOException("cannot replace file");
            if (!tmp.renameTo(dest)) throw new IOException("cannot save file");
        } finally {
            c.disconnect();
            if (tmp.exists()) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    private static String readFile(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            copy(in, out);
        } finally {
            in.close();
        }
        return new String(out.toByteArray(), "UTF-8");
    }

    private static void writeFile(File f, String s) throws IOException {
        OutputStream out = new FileOutputStream(f);
        try {
            out.write(s.getBytes("UTF-8"));
        } finally {
            out.close();
        }
    }
}
